# Comparação com o Flagger real: FLAGGER-V6

Plano `8dce1637419e`.

## Detecção por cenário (mesmas execuções)

| Cenário | Flagger real | Nosso detector | agg_b (emul.) | flagger_rel (emul.) | Real x emulado concordam |
|---|---|---|---|---|---|
| dash10 | 0/30 (0%) | 30/30 (100%) | 0/30 (0%) | 0/30 (0%) | 30/30 |
| heavy10 | 30/30 (100%) | 28/30 (93%) | 30/30 (100%) | 29/30 (97%) | 29/30 |

## Hipóteses

- H6a (dash10, Flagger cego ao dashboard): 0/30 reversões, UB95 0.095: passa
- H6b (heavy10, Flagger vê heavy-reports): 30/30, LI95 0.905: passa
- H6c (controle, Flagger): 0 reversões em 30 execuções: passa
- H7 (dash10, nosso detector x Flagger real): só nós 30, só Flagger 0, p 0.0000, Holm 0.0000: rejeita H0
- H7 (heavy10, nosso detector x Flagger real): só nós 0, só Flagger 2, p 1.0000, Holm 1.0000: não rejeita
- H8 (dash10, emulação x Flagger real): 30/30 concordam: passa
- H8 (heavy10, emulação x Flagger real): 29/30 concordam: passa

## Controle: execuções com alarme falso

- flagger: 0 de 30
- ours: 0 de 30
- emul_agg_b: 0 de 30
- emul_flagger_rel: 0 de 30
