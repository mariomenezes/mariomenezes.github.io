# Avaliação v5: EVAL-V5-sigma0.1

Plano `fca42706d8ba`. Acerto: primeira detecção em (t_on, t_off+60].

## H1 (regra primária, limite inferior unicaudal 95% >= 0,80)

| Cenário | Regra | Detectadas | LI95 | TTD med/p90 | H1 |
|---|---|---|---|---|---|
| dash10 | D | 30/30 | 0.905 | 3.0/3.0 | passa |
| heavy10 | B | 30/30 | 0.905 | 3.0/6.100000000000001 | passa |
| dash20 | D | 30/30 | 0.905 | 3.0/3.0 | secundário |
| heavy20 | B | 30/30 | 0.905 | 3.0/3.0 | secundário |

## H5 (por feature x por versão, McNemar unicaudal, Holm)

| Cenário/método | só feature | só versão | p | p Holm | rejeita H0 |
|---|---|---|---|---|---|
| dash10/agg_b | 30 | 0 | 0.0000 | 0.0000 | sim |
| dash10/flagger_rel | 30 | 0 | 0.0000 | 0.0000 | sim |
| heavy10/agg_b | 0 | 0 | 1.0000 | 1.0000 | não |
| heavy10/flagger_rel | 0 | 0 | 1.0000 | 1.0000 | não |
| dash20/agg_b | 30 | 0 | 0.0000 | 0.0000 | sim |
| dash20/flagger_rel | 30 | 0 | 0.0000 | 0.0000 | sim |
| heavy20/agg_b | 0 | 0 | 1.0000 | 1.0000 | não |
| heavy20/flagger_rel | 0 | 0 | 1.0000 | 1.0000 | não |

## Todas as análises (secundárias)

| Cenário | feature:B | feature:BF | feature:D | agg_b | flagger_rel |
|---|---|---|---|---|---|
| dash10 | 0/30 (0%) | 30/30 (100%) | 30/30 (100%) | 0/30 (0%) | 0/30 (0%) |
| heavy10 | 30/30 (100%) | 30/30 (100%) | 25/30 (83%) | 30/30 (100%) | 30/30 (100%) |
| dash20 | 0/30 (0%) | 30/30 (100%) | 30/30 (100%) | 0/30 (0%) | 0/30 (0%) |
| heavy20 | 30/30 (100%) | 30/30 (100%) | 30/30 (100%) | 30/30 (100%) | 30/30 (100%) |

## H3 (controle: 1800 janelas, 30.0 cluster-horas)

- heavy-reports: 0 alarmes, UB95 0.0999 por cluster-hora: passa
- dashboard: 0 alarmes, UB95 0.0999 por cluster-hora: passa
- agg_b (por versão): alarme em 0 de 128 blocos de 14 janelas
- flagger_rel (por versão): alarme em 0 de 128 blocos de 14 janelas

## H2 (isolamento): passa; violações: 0
