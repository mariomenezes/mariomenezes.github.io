# Comparação com o Flagger real: PILOTO-FLAGGER-descartavel

Plano `e8599c5c6711`.

## Detecção por cenário (mesmas execuções)

| Cenário | Flagger real | Nosso detector | agg_b (emul.) | flagger_rel (emul.) | Real x emulado concordam |
|---|---|---|---|---|---|
| dash10 | 0/2 (0%) | 2/2 (100%) | 0/2 (0%) | 0/2 (0%) | 2/2 |
| heavy10 | 2/2 (100%) | 2/2 (100%) | 2/2 (100%) | 2/2 (100%) | 2/2 |

## Hipóteses

- H6a (dash10, Flagger cego ao dashboard): 0/2 reversões, UB95 0.776: falha
- H6b (heavy10, Flagger vê heavy-reports): 2/2, LI95 0.224: falha
- H6c (controle, Flagger): 0 reversões em 2 execuções: falha
- H7 (dash10, nosso detector x Flagger real): só nós 2, só Flagger 0, p 0.2500, Holm 0.5000: não rejeita
- H7 (heavy10, nosso detector x Flagger real): só nós 0, só Flagger 0, p 1.0000, Holm 1.0000: não rejeita
- H8 (dash10, emulação x Flagger real): 2/2 concordam: falha
- H8 (heavy10, emulação x Flagger real): 2/2 concordam: falha

## Controle: execuções com alarme falso

- flagger: 0 de 2
- ours: 0 de 2
- emul_agg_b: 0 de 2
- emul_flagger_rel: 0 de 2
